package enumPackage;

public class Days {
	public enum day{
		MONDAY, TUESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Enum is used for declaring constant 
		 * Constant value cannot be changed
		 */
		System.out.println(day.MONDAY);
		System.out.println(day.FRIDAY);
		
	}

}
