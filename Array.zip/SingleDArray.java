package general;

public class SingleDArray {
	public static void main(String []args) {
		//Way to declare array
		int a[] = {10,20,30,}; // literal way 
		String []a1= {"A","B","C"};
		int a2[] = new int[5]; // using new keyword 
		a2[0]=10;a2[1]=20;a2[2]=30;a2[3]=400;a2[4]=500;
		for(int i =0;i<a1.length;i++) {
		System.out.println(a1[i]);
		}
		for(int i =0;i<a2.length;i++) {
			System.out.println(a2[i]);
			}
	}

}
