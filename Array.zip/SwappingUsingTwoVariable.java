package general;

import java.util.Scanner;

public class SwappingUsingTwoVariable {
	// Swapping using two variables only 
	void swap() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Two Values for Swapping: ");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		num1 = num1+num2;
		num2 = num1-num2;
		num1 = num1-num2;
		System.out.println("After Swapping num1 "+num1+" num2 is "+num2);
		/*
		 num1 = 10  and num2 20;
		 num1 = num1+num2; num1 = 10+20=30
		 num2 = num1=num2; num2 = 30-20=10
		 num1 = num1-num2; num1 = 30-10 = 20 
		 */
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwappingUsingTwoVariable s1= new SwappingUsingTwoVariable();
		s1.swap();
		
		
		
		

	}

}
