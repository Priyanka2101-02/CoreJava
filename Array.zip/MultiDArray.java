package general;

public class MultiDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][]num = {
				{10,20,30,40},
				{101,102,103,104},
				{1001,1002,1003,1004},
				
		};
		
		for(int i = 0; i<num.length;i++) {
			for(int j=0;j<num[i].length;j++)
			{
				System.out.print(num[i][j]+" ");
			}
			System.out.println();
		}
	}

}
