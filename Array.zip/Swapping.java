package general;

public class Swapping {
	int num1 = 50; // this value erased by 80
	int num2;
	void swap(Swapping obj)// call by reference 
	{
		int num3;
		num3 = obj.num1;
		obj.num1 = obj.num2;
		obj.num2 = num3;
		System.out.println("After Swapping value of num1 "+num1+" and num2 "+num2);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Swapping s = new Swapping();
		s.num1 = 80;
		s.num2 = 40;
		System.out.println("Before Swapping valoe of num1 "+s.num1+" and num2  "+s.num2);
		s.swap(s);
		

	}

}
