package controlFLowStatement;

import java.util.Scanner;

public class EvenorOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter The number");
		int num1= sc.nextInt();
		if(num1%2==0)
		{
			System.out.println("Number is Even!!!!");
			
		}
		else
		{
			System.out.println("Number is Odd!!!!!");
		}
			
		

	}

}
