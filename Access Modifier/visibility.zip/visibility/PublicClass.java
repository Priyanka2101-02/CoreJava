package visibility;
import accessModifier.*;

public class PublicClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample s1 = new Sample();
		s1.display();

	}

}
