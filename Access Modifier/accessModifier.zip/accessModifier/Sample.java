package accessModifier; 
  public class Sample{
	public int num1=10;
	public void display() {
		System.out.println("This methodis from AccessModifier Package!!");
		System.out.println(num1);
	}
	public Sample()
	{
		System.out.println("This is Sample constructor");
	}
	
	
}

