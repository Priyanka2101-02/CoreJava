package accessModifier;
/*
 * This is default access modifier which created the another human class object 
 */

public class DefaultClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human h2 = new Human();
		h2.behaviour("Happy");

	}

}
