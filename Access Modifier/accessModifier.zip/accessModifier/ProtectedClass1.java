package accessModifier;

public class ProtectedClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProtectedClass pc = new ProtectedClass();
		pc.show();

	}

}
