package accessModifier;
/*
 * Default access modifier is accesible in class, outside class but class should reside into same package
 */
class Human{
	String str1;

	void behaviour(String str)
	{
		str1 = str;
		System.out.println(str1);
	}
}

public class DefaultClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human h1 = new Human();
		h1.behaviour("Angry");

	}

}
